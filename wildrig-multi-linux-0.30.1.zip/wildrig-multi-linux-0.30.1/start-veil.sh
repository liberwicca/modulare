#!/bin/bash

while true
do
./wildrig-multi --print-full --algo progpow-veil --url pool.woolypooly.com:3098 --user mt9E8Txf9UFqMmxoYkpkgYjW2ZHmS4a2B1 --pass x
sleep 5
done
